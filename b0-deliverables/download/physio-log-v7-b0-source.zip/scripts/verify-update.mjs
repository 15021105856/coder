/** 独立集成测试：在临时副本中修改数据，验证 build / inject；不会写正式数据。 */
import assert from 'node:assert/strict';
import { cpSync, mkdtempSync, readFileSync, writeFileSync, rmSync, symlinkSync, renameSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { resolve, basename } from 'node:path';
import { execFileSync, spawnSync } from 'node:child_process';
import { readDatasetFromHtml, datasetPayloadEqual } from './dataset-from-html.mjs';
import { dataStamp } from '../src/shared/stamp.js';
import { RELEASE } from '../src/shared/release.js';

const root = resolve(import.meta.dirname, '..');
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';

function run(cwd, ...args) {
  const result = spawnSync(npm, args, { cwd, encoding: 'utf8', env: process.env });
  if (result.status !== 0) throw new Error(`${args.join(' ')} failed:\n${result.stdout}\n${result.stderr}`);
  return result;
}

function runNode(cwd, script, ...scriptArgs) {
  execFileSync(process.execPath, [script, ...scriptArgs], { cwd, stdio: 'inherit', env: process.env });
}

const temp = mkdtempSync(resolve(tmpdir(), 'physio-update-'));
try {
  cpSync(root, temp, {
    recursive: true,
    filter: (p) => {
      const base = basename(p);
      return !['node_modules', 'download', 'release'].includes(base)
        && !base.endsWith('.zip')
        && !/^\.(pack|inject)-/.test(base);
    },
  });
  symlinkSync(resolve(root, 'node_modules'), resolve(temp, 'node_modules'), 'junction');

  // 从空产物目录完成首次构建，验证冷启动链路。
  run(temp, 'run', 'build');
  assert(existsSync(resolve(temp, 'release', RELEASE.monitor)), 'bootstrap build 应生成 release HTML');

  const path = resolve(temp, 'data/训练数据集.json');
  const ds = JSON.parse(readFileSync(path, 'utf8'));
  const originalBaseline = structuredClone(ds._baseline);
  const n = ds.data.length;
  const beforeStamp = dataStamp(ds);

  ds.data.at(-1).pro += 1;
  writeFileSync(path, JSON.stringify(ds, null, 2));
  const afterStamp = dataStamp(ds);
  assert.notEqual(afterStamp, beforeStamp, '测试数据修改应改变指纹');

  runNode(temp, resolve(temp, 'scripts/check.mjs'), path);
  assert.notEqual(
    spawnSync(npm, ['run', 'check:release'], { cwd: temp, encoding: 'utf8' }).status,
    0,
    '旧产物应被交付校验识别',
  );

  run(temp, 'run', 'build');
  for (const name of [RELEASE.monitor, RELEASE.archive]) {
    assert(datasetPayloadEqual(readDatasetFromHtml(resolve(temp, 'release', name)), ds), `${name} 应包含更新后的数据`);
  }
  assert.equal(readFileSync(resolve(temp, 'download.html'), 'utf8').includes(afterStamp), true, 'download.html 应包含新指纹');

  const zipPath = resolve(temp, RELEASE.zipBundle);
  assert(existsSync(zipPath), 'build 应生成成品 ZIP');
  const zipJson = JSON.parse(readFileSync(resolve(temp, 'release/训练数据集.json'), 'utf8'));
  assert.equal(zipJson.data.at(-1).pro, ds.data.at(-1).pro, 'release 内嵌 JSON 应与源数据一致');

  // 注入失败不得先覆盖监测页面或 Word。
  const mp = resolve(temp, 'release', RELEASE.monitor);
  const ap = resolve(temp, 'release', RELEASE.archive);
  const dp = resolve(temp, 'release', RELEASE.docx);
  const oldMonitor = readFileSync(mp);
  const oldWord = readFileSync(dp);

  ds.data.at(-1).pro += 1;
  writeFileSync(path, JSON.stringify(ds, null, 2));
  const injectStamp = dataStamp(ds);
  renameSync(ap, `${ap}.saved`);
  assert.notEqual(spawnSync(npm, ['run', 'inject'], { cwd: temp, encoding: 'utf8' }).status, 0);
  assert.deepEqual(readFileSync(mp), oldMonitor);
  assert.deepEqual(readFileSync(dp), oldWord);
  renameSync(`${ap}.saved`, ap);

  // 旧 zip 中的多余成员必须在下次打包时消失。
  writeFileSync(resolve(temp, 'stale.txt'), 'stale');
  execFileSync('zip', ['-q', zipPath, 'stale.txt'], { cwd: temp });
  run(temp, 'run', 'inject');
  run(temp, 'run', 'check:release');

  for (const name of [RELEASE.monitor, RELEASE.archive]) {
    assert(datasetPayloadEqual(readDatasetFromHtml(resolve(temp, 'release', name)), ds), `inject 后 ${name} 应与源数据一致`);
  }
  assert.equal(readFileSync(resolve(temp, 'download.html'), 'utf8').includes(injectStamp), true, 'inject 后 download.html 应包含新指纹');

  assert.deepEqual(ds._baseline, originalBaseline);
  assert.equal(ds.data.length, n);

  const members = execFileSync('unzip', ['-Z1', zipPath], { encoding: 'utf8' }).trim().split('\n');
  assert.equal(members.length, 5);
  assert(!members.includes('stale.txt'));

  console.log('✓ 更新集成测试：冷启动 build；源校验与交付校验分离；build / inject 同步；注入失败无部分写入；ZIP 无陈旧成员；记录数与固定基线不变');
} finally {
  rmSync(temp, { recursive: true, force: true });
}
