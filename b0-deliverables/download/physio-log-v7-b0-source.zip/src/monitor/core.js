/* 数据与核心算法：唯一真源是内嵌《训练数据集.json》，localStorage 键名与 v5 兼容。 */
import LEGACY_DAILY_SEED from "../../data/legacy-daily-seed.json";
import { readDataset } from "../shared/fx.js";
import { dataStamp } from "../shared/stamp.js";
import { FIELDS, NUM_FIELDS } from "../shared/schema.js";
import { dayMs, pad2, DAY_MS, lastDataDate } from "../shared/time.js";
import { esc, fmtTsec, fmtDur, normPace, fmtPace } from "../shared/format.js";
import { runTotalKg, strengthTotalDetail } from "../shared/daily.js";
import { mergeDailyStore } from "../shared/daily-merge.js";
import { devWarn } from "../shared/log.js";
import { STORAGE_KEYS } from "../shared/release.js";
import { normalizeRec, mergeRecordLists, upsertIntoList, byDate as recByDate } from "../shared/records-io.js";

export { FIELDS, NUM_FIELDS, dayMs, pad2, esc, fmtTsec, fmtDur, normPace, fmtPace };
export { mergeDailyStore } from "../shared/daily-merge.js";
export { normalizeRec } from "../shared/records-io.js";

const DATASET = readDataset();
export const DATASET_VALID = !DATASET._invalid;
export const SEED = DATASET.data || [];
export const DAILY_SEED = DATASET._daily || {};
export const DATASET_META = Object.fromEntries(Object.entries(DATASET).filter(([k]) => k !== "data" && k !== "_daily"));

export const store = { dailyMeta: structuredClone(DAILY_SEED) };
export const DATA_STAMP = dataStamp(DATASET);
export const DATA_DATE = lastDataDate(SEED) || "—";

export const T = {
  HRR_BAND_ENABLED: false,
  HRR_LO: 22.4, HRR_HI: 24.7,
  SHR_LO: 45, SHR_HI: 52,
  CONT_LO: 70,
  PRO_LO: 100, PRO_HI: 115,
  RULE_A_DROP: -8,
  BASELINE_MIN_N: 28,
};

const plainObject = (x) => x !== null && typeof x === "object" && !Array.isArray(x);
const cloneDaily = (x) => (x === undefined ? undefined : structuredClone(x));

export function loadDaily() {
  store.dailyMeta = cloneDaily(DAILY_SEED);
  try {
    const c = JSON.parse(localStorage.getItem(STORAGE_KEYS.daily) || "null");
    if (c && plainObject(c.data)) {
      const base = plainObject(c.seed) ? c.seed : (c.stamp === DATA_STAMP ? DAILY_SEED : LEGACY_DAILY_SEED);
      store.dailyMeta = mergeDailyStore(DAILY_SEED, c.data, base);
    }
  } catch (e) { devWarn("loadDaily", e); }
  saveDaily();
}

export function saveDaily() {
  try {
    localStorage.setItem(STORAGE_KEYS.daily, JSON.stringify({
      stamp: DATA_STAMP,
      date: [DATA_DATE, ...Object.keys(store.dailyMeta)].sort().at(-1),
      seed: DAILY_SEED,
      data: store.dailyMeta,
    }));
  } catch (e) { devWarn("saveDaily", e); }
}

export function weightPoints() {
  return Object.entries(store.dailyMeta).flatMap(([d, m]) => (m.weight || [])
    .filter((w) => w.period === "morning" && Number.isFinite(w.kg))
    .map((w) => ({ d, y: w.kg, time: w.time, confirmed: w.protocol_confirmed }))).sort(byDate);
}

export function weight7(d) {
  const w = weightPoints().filter((x) => dayMs(x.d) <= dayMs(d) && dayMs(x.d) >= dayMs(d) - 6 * DAY_MS);
  return w.length >= 3 ? { value: w.reduce((a, b) => a + b.y, 0) / w.length, n: w.length } : null;
}

export function weightAxis(points) {
  const lo = Math.min(59.5, ...points.map((p) => Math.floor(p.y * 2) / 2));
  const hi = Math.max(63, ...points.map((p) => Math.ceil(p.y * 2) / 2));
  const step = Math.max(0.5, Math.ceil(((hi - lo) / 12) * 2) / 2), ticks = [];
  for (let v = lo; v <= hi + 0.0001; v += step) ticks.push(+v.toFixed(1));
  if (ticks.at(-1) !== hi) ticks.push(hi);
  return { domain: [lo - 0.05, hi + 0.05], ticks };
}

export function strengthTotal(r) {
  return strengthTotalDetail(r, store.dailyMeta[r.d]);
}

export function runTotal(r) {
  return runTotalKg(r, store.dailyMeta[r.d]);
}

export function byDate(a, b) { return recByDate(a, b); }

export function hrrNorm(r) {
  if (r.hrr0 == null || r.hrr1 == null || !r.hrr0) return null;
  return ((r.hrr0 - r.hrr1) / r.hrr0) * 100;
}

export function hrrOut(hp) {
  if (!T.HRR_BAND_ENABLED || hp == null) return false;
  const r1 = Math.round(hp * 10) / 10;
  return r1 < T.HRR_LO || r1 > T.HRR_HI;
}

const DSB = DATASET._baseline || {};
export const DEFAULT_BASELINE = typeof DSB.lnRMSSD_mean === "number" && typeof DSB.lnRMSSD_sd === "number" && DSB.window_start && DSB.window_end
  ? { start: DSB.window_start, end: DSB.window_end, exclude: [...(DSB.excluded || [])], n: DSB.n, mean: DSB.lnRMSSD_mean, sd: DSB.lnRMSSD_sd, locked: true, builtin: true }
  : { start: "2026-08-08", end: "2026-08-23", exclude: ["2026-08-16", "2026-08-17"], n: 14, mean: 4.4417, sd: 0.0935, locked: true, builtin: true };

export function hydrateBaseline(b) {
  if (!b || typeof b.mean !== "number" || typeof b.sd !== "number" || typeof b.start !== "string" || typeof b.end !== "string") return null;
  const exclude = Array.isArray(b.exclude) ? b.exclude.slice() : [];
  const { mean, sd } = b;
  return {
    ...b, exclude,
    lo: mean - sd, hi: mean + sd,
    olo: mean - 1.5 * sd, ohi: mean + 1.5 * sd,
  };
}

const LS_BASE = STORAGE_KEYS.baseline;
let memBaseline = null;

export function loadBaselineLock() {
  if (storage.memMode) {
    const b = hydrateBaseline(memBaseline);
    if (b && b.auto !== true) return b;
    return hydrateBaseline(structuredClone(DEFAULT_BASELINE));
  }
  try {
    const raw = localStorage.getItem(LS_BASE);
    if (raw) {
      const b = hydrateBaseline(JSON.parse(raw));
      if (b) {
        if (b.auto === true) localStorage.removeItem(LS_BASE);
        else return b;
      }
    }
  } catch (e) { devWarn("loadBaselineLock", e); }
  return hydrateBaseline(structuredClone(DEFAULT_BASELINE));
}

export function saveBaselineLock(b) {
  if (storage.memMode) { memBaseline = b; return; }
  try { localStorage.setItem(LS_BASE, JSON.stringify(b)); }
  catch (e) { storage.memMode = true; memBaseline = b; storage.onMem?.(); devWarn("saveBaselineLock", e); }
}

export function clearBaselineLock() {
  if (storage.memMode) { memBaseline = null; return; }
  try { localStorage.removeItem(LS_BASE); } catch (e) { devWarn("clearBaselineLock", e); }
}

export function windowStats(recs, start, end, exclude) {
  const ex = exclude?.length ? new Set(exclude) : null;
  const vals = recs.filter((r) => r.el != null && r.d >= start && r.d <= end && !(ex && ex.has(r.d))).sort(byDate).map((r) => Math.log(r.el));
  const n = vals.length;
  if (n < 2) return null;
  const mean = vals.reduce((a, b) => a + b, 0) / n;
  const sd = Math.sqrt(vals.reduce((a, v) => a + (v - mean) ** 2, 0) / (n - 1));
  return { start, end, n, mean, sd, exclude: exclude?.slice() || [], lo: mean - sd, hi: mean + sd, olo: mean - 1.5 * sd, ohi: mean + 1.5 * sd };
}

export function getBaseline(recs) {
  const lock = loadBaselineLock();
  if (lock) return { ...lock, locked: true };
  const all = recs.filter((r) => r.el != null).sort(byDate);
  if (!all.length) return null;
  return { ...windowStats(recs, all[0].d, all.at(-1).d), locked: false };
}

export function maybeAutoLock(toast) {
  if (loadBaselineLock()) return false;
  const all = state.recs.filter((r) => r.el != null).sort(byDate);
  if (all.length < T.BASELINE_MIN_N) return false;
  const w = windowStats(state.recs, all[0].d, all[T.BASELINE_MIN_N - 1].d);
  if (!w) return false;
  saveBaselineLock({ ...w, lockedAt: new Date().toISOString(), auto: true });
  toast?.(`已满 ${T.BASELINE_MIN_N} 个有效样本，自动锁定最早 ${T.BASELINE_MIN_N} 个为参考期基线`);
  return true;
}

export function rolling7(recs) {
  const out = {};
  const sorted = recs.slice().sort(byDate);
  for (let i = 0; i < sorted.length; i++) {
    const end = dayMs(sorted[i].d), start = end - 6 * DAY_MS;
    const win = [];
    for (let j = i; j >= 0; j--) {
      if (dayMs(sorted[j].d) < start) break;
      if (sorted[j].el != null) win.push(Math.log(sorted[j].el));
    }
    if (win.length >= 3) out[sorted[i].d] = { v: win.reduce((a, b) => a + b, 0) / win.length, n: win.length };
  }
  return out;
}

export function judge(recs, d) {
  const r = recs.find((x) => x.d === d); if (!r) return [];
  const out = [], st = getBaseline(recs), sorted = recs.slice().sort(byDate);
  const prev = sorted.filter((x) => x.d < d && x.el != null).pop();
  if (r.el != null && prev && r.el - prev.el < T.RULE_A_DROP) {
    const gap = Math.round((dayMs(d) - dayMs(prev.d)) / DAY_MS);
    out.push({ level: "info", tag: "数值变化", text: `晨起RMSSD较${prev.d}下降${(prev.el - r.el).toFixed(1)}ms。${gap === 1 && r.shr != null && prev.shr != null ? `睡眠平均心率变化${r.shr - prev.shr}bpm；这两项变化不能单独区分疲劳与测量因素。` : `间隔${gap}天或缺少对应心率，不作单日归因。`}` });
  }
  if (st) {
    const rolls = rolling7(recs); let streak = 0, lastDay = null, lastV = null;
    for (const x of sorted) {
      if (x.d > d) break;
      const ro = rolls[x.d];
      if (!ro || x.el == null) { streak = 0; lastDay = null; continue; }
      if (lastDay && dayMs(x.d) - dayMs(lastDay) !== DAY_MS) streak = 0;
      streak = ro.v < st.lo ? streak + 1 : 0; lastDay = x.d; lastV = ro.v;
    }
    if (streak >= 3 && r.el != null) out.push({ level: "info", tag: "滚动趋势", text: `连续${streak}个日历日有晨测，7日滚动均值低于固定参考带；当前折算约${Math.exp(lastV).toFixed(1)}ms。仅描述趋势，不诊断恢复状态。` });
  }
  const shrRange = store.dailyMeta[d]?.sleep?.shr_range || [T.SHR_LO, T.SHR_HI];
  if (r.shr != null && (r.shr < shrRange[0] || r.shr > shrRange[1])) out.push({ level: "info", tag: "睡眠心率", text: `平均心率${r.shr}bpm超出所用参考区间${shrRange.join("–")}bpm，结合当日背景查看。` });
  if (r.cont != null && r.cont < T.CONT_LO) out.push({ level: "info", tag: "设备指标", text: `深睡连续性${r.cont}低于既有提示线${T.CONT_LO}；不单独判断恢复。` });
  if (r.pro != null && r.pro < T.PRO_LO) out.push({ level: "info", tag: "营养估计", text: `蛋白代表估值${r.pro}g低于既有参考值${T.PRO_LO}g；请结合估算范围，不能确认实际不足。` });
  return out;
}

const LS_KEY = STORAGE_KEYS.records;
const LS_VER = STORAGE_KEYS.dataVersion;
export const storage = { memMode: false, memStore: null, staleVer: null, onMem: null };
export const state = { recs: [], sel: null, view: "today" };

function storageAvailable() {
  try { const k = "__t" + Date.now(); localStorage.setItem(k, "1"); localStorage.removeItem(k); return true; }
  catch { return false; }
}

export function loadRecords() {
  if (storageAvailable()) {
    const rawVer = localStorage.getItem(LS_VER);
    let vStamp = null, vDate = null;
    if (rawVer) {
      if (rawVer[0] === "{") { try { const o = JSON.parse(rawVer); vStamp = o.s || null; vDate = o.d || null; } catch (e) { devWarn("loadRecords.ver", e); } }
      else vDate = rawVer;
    }
    let cached = null;
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) { const arr = JSON.parse(raw); if (Array.isArray(arr) && arr.length) cached = arr.map(normalizeRec); }
    } catch (e) { devWarn("loadRecords.cache", e); cached = null; }
    try {
      if (cached && (vStamp === DATA_STAMP || (!vStamp && vDate === DATA_DATE))) return cached;
      if (cached && vDate && vDate > DATA_DATE) { storage.staleVer = vDate; return cached; }
      const merged = mergeRecordLists(SEED, cached);
      localStorage.setItem(LS_KEY, JSON.stringify(merged));
      localStorage.setItem(LS_VER, JSON.stringify({ s: DATA_STAMP, d: DATA_DATE }));
      return merged;
    } catch (e) { devWarn("loadRecords.merge", e); }
  }
  storage.memMode = true;
  if (!storage.memStore) storage.memStore = SEED.map(normalizeRec);
  return storage.memStore;
}

export function saveRecords(recs) {
  if (storage.memMode) { storage.memStore = recs; return; }
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(recs));
    localStorage.setItem(LS_VER, JSON.stringify({ s: DATA_STAMP, d: DATA_DATE }));
  } catch (e) { storage.memMode = true; storage.memStore = recs; storage.onMem?.(); devWarn("saveRecords", e); }
}

export function upsertRecords(list, toast) {
  const { recs, add, upd, skip } = upsertIntoList(state.recs, list);
  state.recs = recs;
  saveRecords(state.recs);
  maybeAutoLock(toast);
  return { add, upd, skip };
}

export function sortedRecs() { return state.recs.slice().sort(byDate); }

export function xExtent(recs) {
  if (!recs.length) { const t = Date.now(); return [t - 7 * DAY_MS, t]; }
  const sorted = recs.slice().sort(byDate);
  return [dayMs(sorted[0].d) - DAY_MS / 2, dayMs(sorted.at(-1).d) + DAY_MS / 2];
}

export function bandPos(el, st) {
  if (el == null || !st) return null;
  const lv = Math.log(el);
  if (lv < st.olo || lv > st.ohi) return "out";
  if (lv < st.lo || lv > st.hi) return "edge";
  return "in";
}
